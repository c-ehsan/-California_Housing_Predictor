# 🏠 California Housing Price Predictor

A machine learning web app that predicts California house prices based on census data.

## 🚀 Features
- Trained using Random Forest Regressor
- Interactive web interface built with Streamlit
- Scaled data using StandardScaler
- Achieved R² = 0.70 on test set

## 🧠 Tech Stack
- Python
- scikit-learn
- pandas
- numpy
- streamlit

## 📁 Project Structure
