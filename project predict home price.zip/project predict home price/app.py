import streamlit as st
import numpy as np 
import joblib 


# لود مدل و اسکیلر
model = joblib.load("model/model.pkl")
scaler = joblib.load("model/scaler.pkl")

st.title("🏠 California House Price Predictor")
st.write("پیش‌بینی قیمت خانه بر اساس ویژگی‌های منطقه")

# ورودی کاربر
longitude = st.number_input("📍 Longitude", value=-120.0)
latitude = st.number_input("📍 Latitude", value=35.0)
housing_median_age = st.number_input("🏠 Housing Median Age", value=25)
total_rooms = st.number_input("🛏 Total Rooms", value=2000)
total_bedrooms = st.number_input("🛏 Total Bedrooms", value=400)
population = st.number_input("👨‍👩‍👧 Population", value=800)
households = st.number_input("🏘 Households", value=300)
median_income = st.number_input("💵 Median Income", value=3.5)

if st.button("🔮 Predict House Value"):
    input_data = np.array([[longitude, latitude, housing_median_age,
                            total_rooms, total_bedrooms,
                            population, households, median_income]])
    input_scaled = scaler.transform(input_data)
    prediction = model.predict(input_scaled)[0]

    st.success(f"🏡 Predicted House Value: ${prediction:,.2f}")
